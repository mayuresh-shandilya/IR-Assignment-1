#!/usr/bin/env python
# coding: utf-8

# In[10]:


import os
import re
import nltk
import pickle
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.stem import PorterStemmer
ps = PorterStemmer()
import numpy as np
import math
import pandas as pd
import sys

# In[11]:


with open('../pkl file/document_frequency.pkl','rb') as file:
    df=pickle.load(file)
    file.close()
    
with open('../pkl file/file_index.pkl','rb') as file:
    file_no=pickle.load(file)
    file.close()
    
with open('../pkl file/Total_words.pkl','rb') as file:
    total_words=pickle.load(file)
    file.close()
    
with open('../pkl file/L2_norm.pkl','rb') as file:
    l2_norm=pickle.load(file)
    file.close()


# In[12]:

def dirback():
    m = os.getcwd()
    n = m.rfind("/")
    d = m[0: n+1]
    os.chdir(d)
    return None

dirback()

file_name=sys.argv[1]
file_name+=".txt"
query = open(file_name,'r')
query_lst={}
for q in query:
    new_text = q.split("\t")
    query_lst[new_text[1].replace("\n","")] = new_text[0].replace("\n", "")


# In[13]:


qid=[]
it=[]
doc_id={}
relev={}
stop = set(stopwords.words('english'))
for a,b in query_lst.items():
    doc_id[a]=[]
    relev[a]=[]
for a,b in query_lst.items():
    eachf=re.sub(r'[^\w\s]',' ',a)             #removing special characters
    encoded_string = eachf.encode("ascii", "ignore")    #removing non ascii charachters
    eachf = encoded_string.decode()  
    tok=word_tokenize(eachf)                       #tokenizing all words in the query
    words=[]
    for t in tok:
        try:
            t=num2words(int(t))              #converting number to words 
        except:
            pass
        words.append(t)
    stem=[]
    for j in tok:
        stem.append(ps.stem(j).lower())            #stematizing tokens
    fin=[]
    for i in stem:
        if i not in stop:                          #removing stopwords 
            if i in df.keys():                     #cheaking if word present in unique keys
                fin.append(i)

    lst=[]
    x=0
    for i in fin:
        tf_idf=(fin.count(i)*math.log(len(file_no)/df[i]))    #buliding query vector
        lst.append(tf_idf)
        x+=tf_idf**2
    x=math.sqrt(x)
    lst1=np.array(lst)/x


    score={}
    for i in range(len(file_no)):
        k=[]
        for j in fin:
            tf_idf=(total_words[i].count(j)*math.log(len(file_no)/df[j]))         #building document vector 
            k.append(tf_idf)
        k=np.array(k)/l2_norm[i]
        score[i]=np.dot(lst1,k)

    score=sorted(score.items(),key=lambda x:x[1],reverse=True)
    cnt=0
    for i in score:
        if(cnt==5):
            break
        y=file_no[i[0]].replace(".txt","")
        doc_id[a].append(y)
        qid.append(b)
        it.append(1)
        if(i[1]>0):
            relev[a].append(1)
        else:
            relev[a].append(0)
        cnt+=1


# In[14]:


d1=[]
r1=[]
for i in doc_id:
    for j in doc_id[i]:
        d1.append(j)
    for j in relev[i]:
        r1.append(j)


# In[16]:


oupt = pd.DataFrame(columns=['queryid','iteration','docid','relevence'])
oupt['queryid'] = qid
oupt['iteration'] = it
oupt['docid'] = d1
oupt['relevence'] = r1
oupt.to_csv('QRels_TF_IDF.csv',index=False)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




