python3 Q4-bm25.py $1
echo Q4-bm25 done
python3 Q4-tf-idf.py $1
echo Q4-tf-idf done
python3 Q4-BRS.py $1
echo Q4-BRS done
