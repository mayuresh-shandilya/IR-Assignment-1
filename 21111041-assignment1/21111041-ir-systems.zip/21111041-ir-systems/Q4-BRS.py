#!/usr/bin/env python
# coding: utf-8

# In[6]:


import os
import re
import nltk
import pickle
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.stem import PorterStemmer
ps = PorterStemmer()
import numpy as np
import math
import pandas as pd
import sys

# In[7]:


temp=open('../pkl file/posting_list.pkl',"rb")
plst=pickle.load(temp)

temp=open('../pkl file/file_index.pkl','rb')
file_index=pickle.load(temp)

temp=open('../pkl file/unique_tokens.pkl','rb')
dit=pickle.load(temp)


# In[8]:

def dirback():
    m = os.getcwd()
    n = m.rfind("/")
    d = m[0: n+1]
    os.chdir(d)
    return None

dirback()

file_name=sys.argv[1]
file_name+=".txt"
query = open(file_name,'r')
query_lst={}
for q in query:
    new_text = q.split("\t")
    query_lst[new_text[1].replace("\n","")] = new_text[0].replace("\n", "")


# In[9]:


doc_brs=[]
relbrs=[]
qidbrs=[]
itbrs=[]
stop = set(stopwords.words('english'))
stop.remove("and")
stop.remove("or")
for a,c in query_lst.items():

    eachf=re.sub(r'[^\w\s]',' ',a)              #removing special characters
    encoded_string = eachf.encode("ascii", "ignore")    #removing non ascii charachters
    eachf = encoded_string.decode()  
    tok=word_tokenize(eachf)                      #tokenizing all words in the query
    words=[]
    for t in tok:
        try:
            t=num2words(int(t))              #converting number to words 
        except:
            pass
        words.append(t)
    stem=[]
    for j in tok:
        stem.append(ps.stem(j).lower())            #stematizing tokens
    fin=[]
    for i in stem:
        if i not in stop:                         #removing stopwords 
            fin.append(i)
    opt=[]

    for i in range(len(fin)-1):
        opt.append("and")
    #creating boolean vector for each operand representing word present in that document index or not
    boolmat=[]
    mmat=[]
    x=len(file_index)
    tokn=set(dit.keys())
    for i in fin:
        boolmat=[0]*x
        if i in tokn:
            for j in plst[i].keys():
                boolmat[j]=1
        mmat.append(boolmat)
            
    for i in opt:
        vector1=mmat[0]
        vector2=mmat[1]
        result=[b1&b2 for b1,b2 in zip(vector1,vector2)]
        mmat.pop(0)
        mmat.pop(0)
        mmat.insert(0,result)
        
    final_word_vector=mmat[0]
    
    cnt=0
    filebrs={}
    for i in final_word_vector:
        if i==1:
            filebrs[file_index[cnt].replace(".txt","")]=1
        else:
            filebrs[file_index[cnt].replace(".txt","")]=0
        cnt+=1
    filebrs=sorted(filebrs.items(),key=lambda item: item[1],reverse=True)
    z=0
    for i in filebrs:
        if z==5:
            break
        qidbrs.append(c)
        itbrs.append(1)
        doc_brs.append(i[0])
        if i[1]==1:
            relbrs.append(1)
        else:
            relbrs.append(0)
        z+=1


# In[10]:


ouptbrs = pd.DataFrame(columns=['queryid','iteration','docid','relevence'])
ouptbrs['queryid'] = qidbrs
ouptbrs['iteration'] = itbrs
ouptbrs['docid'] = doc_brs
ouptbrs['relevence'] = relbrs
ouptbrs.to_csv('QRels_BRS.csv',index=False)


# In[ ]:




