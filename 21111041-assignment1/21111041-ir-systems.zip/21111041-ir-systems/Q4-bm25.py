#!/usr/bin/env python
# coding: utf-8

# In[12]:


import os
import re
import nltk
import pickle
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.stem import PorterStemmer
ps = PorterStemmer()
import numpy as np
import math
import pandas as pd
import sys

# In[13]:


with open('../pkl file/file_index.pkl','rb') as file:
    file_no=pickle.load(file)
    file.close()
    
with open('../pkl file/posting_list.pkl','rb') as file:
    tf=pickle.load(file)
    file.close()
    
with open('../pkl file/document_frequency.pkl','rb') as file:
    df=pickle.load(file)
    file.close()
    
with open('../pkl file/document_length.pkl','rb') as file:
    doc_len=pickle.load(file)
    file.close()


# In[14]:

def dirback():
    m = os.getcwd()
    n = m.rfind("/")
    d = m[0: n+1]
    os.chdir(d)
    return None

dirback()

file_name=sys.argv[1]
file_name+=".txt"
query = open(file_name,'r')
query_lst={}
for q in query:
    new_text = q.split("\t")
    query_lst[new_text[1].replace("\n","")] = new_text[0].replace("\n", "")


# In[15]:


doc_bm={}
relbm={}
qidbm=[]
itbm=[]
stop = set(stopwords.words('english'))
for a,c in query_lst.items():
    doc_bm[a]=[]
    relbm[a]=[]
for a,c in query_lst.items():
    eachf=re.sub(r'[^\w\s]',' ',a)           #removing special characters
    encoded_string = eachf.encode("ascii", "ignore")    #removing non ascii charachters
    eachf = encoded_string.decode()  
    tok=word_tokenize(eachf)                      #tokenizing all words in the query
    words=[]
    for t in tok:
        try:
            t=num2words(int(t))              #converting number to words 
        except:
            pass
        words.append(t)
    stem=[]
    for j in tok:
        stem.append(ps.stem(j).lower())            #stematizing tokens
    fin=[]
    for i in stem:
        if i not in stop:                         #removing stop words
            fin.append(i)
    avg=0
    for i in range(len(doc_len)):                  #calculating average legth of all documents
        avg+=doc_len[i]
    avg=avg/len(doc_len)

    k=1.2
    b=0.75
    score={}
    for i in range(len(file_no)):
        score[i]=0
        for j in fin:
            curtf=0
            curdf=0
            idf=0
            if j in tf:
                if i in tf[j]:
                    curtf=tf[j][i]                 #retrieving term frequency from 
            if j in df:
                curdf=df[j]                        #retrieving document frequency from
                idf=math.log((len(file_no)-curdf+0.5)/(curdf+0.5)+1)
                score[i]+=idf*((k+1)*curtf/(curtf+k*(1-b+b*(doc_len[i]/avg))))

    score1=sorted(score.items(),key=lambda item: item[1],reverse=True)
    x=0
    for i in score1:
        if(x==5):
            break
        y=file_no[i[0]].replace(".txt","")
        doc_bm[a].append(y)
        qidbm.append(c)
        itbm.append(1)
        if(i[1]>0):
            relbm[a].append(1)
        else:
            relbm[a].append(0)
        x+=1


# In[16]:


d2=[]
r2=[]
x=0
for i in doc_bm:
    for j in doc_bm[i]:
        d2.append(j)
        x+=1
    for j in relbm[i]:
        r2.append(j)


# In[17]:


ouptbm = pd.DataFrame(columns=['queryid','iteration','docid','relevence'])
ouptbm['queryid'] = qidbm
ouptbm['iteration'] = itbm
ouptbm['docid'] = d2
ouptbm['relevence'] = r2
ouptbm.to_csv('QRels_BM25.csv',index=False)


# In[ ]:




